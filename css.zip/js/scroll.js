
    $(window).on('scroll', function() {
        if ($(window).scrollTop()) {
            $('.navbar').addClass('abc');
        } else {
            $('.navbar').removeClass('abc')
        }
    })

